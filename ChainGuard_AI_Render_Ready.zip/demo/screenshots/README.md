Add final screenshots after running the application.
