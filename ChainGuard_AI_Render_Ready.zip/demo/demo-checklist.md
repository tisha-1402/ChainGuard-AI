# 3–5 Minute Demo
1. Dashboard — disruptions, critical shipments, fleet, alerts.
2. Open a critical shipment — show risk score and recommended action.
3. Open Cold Chain — show temperature excursions.
4. Open Bob Assistant — ask about cold-chain alerts.
5. Explain impact and future scope.
