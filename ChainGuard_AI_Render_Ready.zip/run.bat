@echo off
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
pip install -r src\requirements.txt
python src\seed.py
python src\app.py
