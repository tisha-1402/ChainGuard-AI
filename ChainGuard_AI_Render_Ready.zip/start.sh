#!/bin/sh
python src/seed.py
exec gunicorn --chdir src app:app --bind 0.0.0.0:${PORT:-10000}
