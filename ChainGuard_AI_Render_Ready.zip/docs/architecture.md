# Architecture
Browser → Flask Web App → SQLite
                         ├→ Risk Engine
                         ├→ Recommendation Engine
                         ├→ Cold-Chain Monitor
                         └→ IBM Bob Adapter
