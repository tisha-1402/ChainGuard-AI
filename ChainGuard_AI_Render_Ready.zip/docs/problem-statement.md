# Problem Statement — L2
Disruptions such as weather events, port strikes and geopolitical crises can cascade across shipments.
Fleet assets may be idle while routes become overloaded, and cold-chain shipments are vulnerable to
temperature excursions discovered too late. The solution identifies affected shipments, recommends
rerouting/carrier alternatives, identifies idle fleet assets, and monitors cold-chain IoT logs.
