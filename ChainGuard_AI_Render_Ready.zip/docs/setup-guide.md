# Setup
Run:
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r src\requirements.txt
python src\seed.py
python src\app.py
```
Then open http://127.0.0.1:5000
