from flask import Flask, render_template, request, jsonify
from services.db import query_db
from services.risk import shipment_risk
from services.recommendation import recommend_action
from services.bob_service import ask_bob

app = Flask(__name__)
app.config["SECRET_KEY"] = "chainguard-demo"

@app.route("/")
def dashboard():
    disruptions = query_db("SELECT * FROM disruptions ORDER BY severity DESC")
    shipments = query_db("SELECT * FROM shipments ORDER BY risk_score DESC")
    fleet = query_db("SELECT * FROM fleet ORDER BY status, asset_id")
    alerts = query_db("SELECT * FROM temperature_logs WHERE excursion=1 ORDER BY recorded_at DESC")
    critical = sum(1 for s in shipments if s["risk_score"] >= 75)
    idle = sum(1 for f in fleet if f["status"].lower() in ("idle", "available"))
    return render_template("dashboard.html", disruptions=disruptions, shipments=shipments,
                           fleet=fleet, alerts=alerts, critical=critical, idle=idle)

@app.route("/shipment/<int:shipment_id>")
def shipment(shipment_id):
    row = query_db("SELECT * FROM shipments WHERE shipment_id=?", (shipment_id,), one=True)
    if not row:
        return "Shipment not found", 404
    risk = shipment_risk(dict(row))
    action = recommend_action(dict(row), risk)
    return render_template("shipment.html", shipment=row, risk=risk, action=action)

@app.route("/cold-chain")
def cold_chain():
    sql = "SELECT t.*, s.cargo, s.route FROM temperature_logs t JOIN shipments s ON s.shipment_id=t.shipment_id ORDER BY t.recorded_at DESC"
    logs = query_db(sql)
    return render_template("cold_chain.html", logs=logs)

@app.route("/assistant", methods=["GET", "POST"])
def assistant():
    answer = None
    question = ""
    if request.method == "POST":
        question = request.form.get("question", "").strip()
        answer = ask_bob(question)
    return render_template("assistant.html", answer=answer, question=question)

@app.route("/api/risk/<int:shipment_id>")
def risk_api(shipment_id):
    row = query_db("SELECT * FROM shipments WHERE shipment_id=?", (shipment_id,), one=True)
    if not row:
        return jsonify({"error": "Shipment not found"}), 404
    return jsonify(shipment_risk(dict(row)))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
