import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "chainguard.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def query_db(sql, params=(), one=False):
    conn = get_db()
    try:
        rows = conn.execute(sql, params).fetchall()
        return (rows[0] if rows else None) if one else rows
    finally:
        conn.close()
