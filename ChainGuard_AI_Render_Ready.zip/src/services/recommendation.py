def recommend_action(shipment, risk):
    cargo = (shipment.get("cargo_type") or "").lower()
    delay = float(shipment.get("delay_hours") or 0)
    if cargo == "cold-chain" and risk["score"] >= 50:
        return "Immediate reroute + temperature escalation. Select an approved carrier and monitor continuously."
    if risk["score"] >= 75:
        return "Prioritise shipment, compare alternate carriers, and redeploy nearby idle fleet capacity."
    if delay >= 6:
        return "Switch to an alternate route/carrier and notify the operations team."
    return "Continue monitoring and review route capacity before the next dispatch."
