def shipment_risk(shipment):
    score = 0
    p = (shipment.get("priority") or "").lower()
    ct = (shipment.get("cargo_type") or "").lower()
    delay = float(shipment.get("delay_hours") or 0)
    score += 30 if p == "critical" else 20 if p == "high" else 10 if p == "medium" else 0
    score += min(30, int(delay * 3))
    score += 25 if ct == "cold-chain" else 0
    score += 15 if shipment.get("disruption_id") else 0
    score = min(100, score)
    level = "Critical" if score >= 75 else "High" if score >= 50 else "Medium" if score >= 25 else "Low"
    return {"score": score, "level": level}
