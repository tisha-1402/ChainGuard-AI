import os
import requests
from dotenv import load_dotenv
load_dotenv()

def local_fallback(question):
    q = question.lower()
    if "cold" in q or "temperature" in q:
        return "Inspect excursion alerts, isolate affected shipments, verify severity, and use an approved alternate carrier."
    if "fleet" in q or "idle" in q:
        return "Redeploy idle/available assets closest to disrupted routes after checking capacity and cargo requirements."
    if "reroute" in q or "route" in q:
        return "Prioritise critical shipments, compare alternate routes/carriers, then monitor ETA and disruption status."
    return "Prioritise critical shipments, reroute disrupted loads, redeploy idle fleet assets, and investigate cold-chain excursions."

def ask_bob(question):
    url, key = os.getenv("BOB_API_URL","").strip(), os.getenv("BOB_API_KEY","").strip()
    if not url or not key:
        return local_fallback(question)
    try:
        r = requests.post(url, headers={"Authorization": f"Bearer {key}", "Content-Type":"application/json"},
                           json={"model": os.getenv("BOB_MODEL",""), "message": question}, timeout=20)
        r.raise_for_status()
        data = r.json()
        return data.get("answer") or data.get("response") or str(data)
    except Exception:
        return "IBM Bob endpoint could not be reached; local demo assistant was used."
