import sqlite3
from pathlib import Path
DB=Path(__file__).resolve().parent/"chainguard.db"
if DB.exists(): DB.unlink()
c=sqlite3.connect(DB); x=c.cursor()
x.executescript('''
CREATE TABLE disruptions(disruption_id INTEGER PRIMARY KEY,type TEXT,location TEXT,severity INTEGER,description TEXT);
CREATE TABLE shipments(shipment_id INTEGER PRIMARY KEY,cargo TEXT,cargo_type TEXT,route TEXT,priority TEXT,delay_hours REAL,disruption_id INTEGER,risk_score INTEGER);
CREATE TABLE fleet(asset_id TEXT PRIMARY KEY,asset_type TEXT,location TEXT,status TEXT,capacity REAL);
CREATE TABLE temperature_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,shipment_id INTEGER,recorded_at TEXT,temperature REAL,excursion INTEGER);
''')
x.executemany("INSERT INTO disruptions VALUES (?,?,?,?,?)",[(1,"Severe Weather","Mumbai–Pune corridor",3,"Heavy rainfall is slowing road movement."),(2,"Port Congestion","JNPT",2,"Container dwell time has increased."),(3,"Carrier Disruption","Ahmedabad",2,"Carrier capacity temporarily reduced.")])
x.executemany("INSERT INTO shipments VALUES (?,?,?,?,?,?,?,?)",[(1001,"Vaccines","cold-chain","Mumbai → Pune","Critical",8,1,0),(1002,"Electronics","general","JNPT → Delhi","High",6,2,0),(1003,"Perishable Food","cold-chain","Mumbai → Ahmedabad","High",4,3,0),(1004,"Textiles","general","Surat → Delhi","Medium",2,3,0),(1005,"Medical Supplies","general","Vadodara → Mumbai","Critical",0,None,0)])
x.executemany("INSERT INTO fleet VALUES (?,?,?,?,?)",[("TRK-101","Refrigerated Truck","Mumbai","Idle",12),("TRK-102","Truck","Pune","In Transit",15),("CNT-501","Container","JNPT","Available",25),("VAN-301","Van","Ahmedabad","Idle",5),("TRK-103","Truck","Vadodara","Available",10)])
x.executemany("INSERT INTO temperature_logs(shipment_id,recorded_at,temperature,excursion) VALUES (?,?,?,?)",[(1001,"2026-09-15 09:10",8.2,0),(1001,"2026-09-15 09:40",10.8,1),(1001,"2026-09-15 10:10",11.5,1),(1003,"2026-09-15 09:20",5.1,0),(1003,"2026-09-15 10:00",9.2,1)])
for sid,p,d,ct,di in x.execute("SELECT shipment_id,priority,delay_hours,cargo_type,disruption_id FROM shipments").fetchall():
    score=(30 if p=="Critical" else 20 if p=="High" else 10 if p=="Medium" else 0)+min(30,int(d*3))+(25 if ct=="cold-chain" else 0)+(15 if di else 0)
    x.execute("UPDATE shipments SET risk_score=? WHERE shipment_id=?",(min(100,score),sid))
c.commit(); c.close(); print("Database created:",DB)
