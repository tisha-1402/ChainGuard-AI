# PPT outline
1 Title  2 Problem  3 Impact  4 Solution  5 Architecture
6 Shipment Risk  7 Fleet Utilisation  8 Cold Chain  9 IBM Bob  10 Demo & Impact
